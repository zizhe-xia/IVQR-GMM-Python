from distutils.core import setup

setup(name='IVQR_GMM',
      packages=['ivqr_gmm'],
      version='0.1',
      description='Using GMM method to calculate the instrument variable quantile regression model proposed by Chen and Lee (2018).',
      url='https://github.com/jordanxzz/IVQR-GMM-Python-codes',
      download_url='https://github.com/jordanxzz/IVQR-GMM-Python-codes/blob/master/ivqr_gmm-0.1.tar.gz',
      author='Zizhe Xia',
      author_email='xiazizhejordan@gmail.com',
      classifiers = ['Programming Language :: Python :: 3.6'],
      python_requires='==3.6.*',
      zip_safe=False)
